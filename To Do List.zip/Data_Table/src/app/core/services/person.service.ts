import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { personsData } from '../constants/persons-static-data';
import { Person } from '../models/person';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  persons$: BehaviorSubject<Person[]>; // Specify Person[] as the type for BehaviorSubject
  persons: Person[] = []; // Initialize persons as an empty array of Person objects

  constructor() {
    this.persons$ = new BehaviorSubject<Person[]>([]); // Initialize BehaviorSubject with an empty array of Person
    this.persons = personsData; // Assuming personsData is already defined and contains an array of Person objects
  }

  getAll() {
    this.persons$.next(this.persons);
  }

  add(person: Person) {
    this.persons.push(person);
  }

  edit(person: Person) {
    let findElem = this.persons.find(p => p.id === person.id);

    if (findElem) {
      // Update properties of findElem with person's properties
      findElem.firstName = person.firstName;
      findElem.age = person.age;
      findElem.job = person.job;

      // Emit updated array using BehaviorSubject
      this.persons$.next(this.persons);
    } else {
      console.error(`Person with id ${person.id} not found.`);
    }
  }

  remove(id: number) {

    this.persons = this.persons.filter(p => {
      return p.id != id
    });

    this.persons$.next(this.persons);
  }

}
