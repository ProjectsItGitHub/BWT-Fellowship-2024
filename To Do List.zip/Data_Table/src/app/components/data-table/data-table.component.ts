import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { PersonFormDialogComponent } from '../person-form-dialog/person-form-dialog.component';
import { Person } from '../../core/models/person';
import { PersonService } from '../../core/services/person.service';




@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  public displayedColumns: string[] = ['firstName', 'age', 'job'];
  public columnsToDisplay: string[] = [...this.displayedColumns, 'actions'];
  dataSource: MatTableDataSource<Person>;
  private serviceSubscribe!: Subscription;

  // Object to hold filter values
  columnsFilters: { [key: string]: { [key: string]: any } } = {};

  constructor(private personsService: PersonService, public dialog: MatDialog) {
    this.dataSource = new MatTableDataSource<Person>();
  }

  ngOnInit(): void {
    this.personsService.getAll();
    this.serviceSubscribe = this.personsService.persons$.subscribe(res => {
      this.dataSource.data = res;
    });
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnDestroy(): void {
    this.serviceSubscribe.unsubscribe();
  }

  applyFilter(columnName: string, operationType: string, searchValue: string): void {
    this.columnsFilters[columnName] = {};
    this.columnsFilters[columnName][operationType] = searchValue;
    this.filter();
  }

  clearFilter(columnName: string): void {
    if (this.columnsFilters[columnName]) {
      delete this.columnsFilters[columnName];
      this.filter();
    }
  }

  edit(data: Person): void {
    const dialogRef = this.dialog.open(PersonFormDialogComponent, {
      width: '400px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.personsService.edit(result);
      }
    });
  }

  delete(id: any): void {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.personsService.remove(id);
      }
    });
  }

  private filter(): void {
    this.dataSource.filterPredicate = (data: Person, filter: string) => {
      let find = true;

      for (var columnName in this.columnsFilters) {
        
       if (Object.prototype.hasOwnProperty.call(this.columnsFilters, columnName)) {
          
        const currentData = columnName;

          if (!this.columnsFilters[columnName]) {
            continue;
          }

          let searchValue = this.columnsFilters[columnName]["contains"];
          if (!!searchValue && currentData.indexOf("" + searchValue) < 0) {
            find = false;
            break;
          }

          searchValue = this.columnsFilters[columnName]["equals"];
          if (!!searchValue && currentData !== searchValue) {
            find = false;
            break;
          }

          searchValue = this.columnsFilters[columnName]["greaterThan"];
          if (!!searchValue && parseFloat(currentData) <= parseFloat(searchValue)) {
            find = false;
            break;
          }

          searchValue = this.columnsFilters[columnName]["lessThan"];
          if (!!searchValue && parseFloat(currentData) >= parseFloat(searchValue)) {
            find = false;
            break;
          }

          searchValue = this.columnsFilters[columnName]["startWith"];
          if (!!searchValue && !currentData.startsWith("" + searchValue)) {
            find = false;
            break;
          }

          searchValue = this.columnsFilters[columnName]["endWith"];
          if (!!searchValue && !currentData.endsWith("" + searchValue)) {
            find = false;
            break;
          }
        }
      }

      return find;
    };

    this.dataSource.filter = 'activate'; // Activate filtering
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
