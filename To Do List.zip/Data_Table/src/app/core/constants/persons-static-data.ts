import { Person } from "../models/person";

export const personsData : Person[] = [
  new Person(1, 'person 1', 30, 'Software Developer'),
  new Person(2, 'person 2', 33, 'Dentist'),
  new Person(3, 'person 3', 32, 'Physician Assistant'),
  new Person(4, 'person 4', 33, 'Software Developer'),
  new Person(5, 'person 5', 34, 'Software Developer'),
  new Person(6, 'person 6', 25, 'Nurse'),
  new Person(7, 'person 7', 36, 'Software Developer'),
  new Person(8, 'person 8', 27, 'Physician'),
  new Person(9, 'person 9', 28, 'Software Developer'),
  new Person(10, 'person 10', 28, 'Software Developer')
]
